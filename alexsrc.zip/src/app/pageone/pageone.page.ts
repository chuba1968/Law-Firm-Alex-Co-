import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pageone',
  templateUrl: './pageone.page.html',
  styleUrls: ['./pageone.page.scss'],
})
export class PageonePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
